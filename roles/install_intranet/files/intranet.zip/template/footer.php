	     </main>
	     <footer class="page-footer dark">
	         <div class="footer-copyright">
	             <p>© FFINFINIT</p>
	         </div>
	     </footer>
	     <!-- Import local -->
	     <script defer src="assets/bootstrap/js/bootstrap.min.js"></script>
	     <script src="assets/js/jquery.min.js"></script>
	     <script src="assets/js/theme.js"></script>
	     <script src="assets/js/fields.dynamic.form.js"></script>
	     <script src="assets/js/menu.hide.scroll.down.js"></script>

	     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

	     <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.js"></script>

	     <!-- CSV 
	    <script defer src="https://code.jquery.com/jquery-3.6.0.js" 
	    	integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" 
	    	crossorigin="anonymous">
	    </script>-->

	    <script defer type="text/javascript" src="assets/js/script-tabela-csv.js"></script>
	    
	     <!-- Option 2: Separate Popper and Bootstrap JS -->
		 <script defer src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" 
		    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" 
		    crossorigin="anonymous">
		</script>
		    
		<script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" 
		    integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" 
		    crossorigin="anonymous">
		</script>
	 </body>
 </html>