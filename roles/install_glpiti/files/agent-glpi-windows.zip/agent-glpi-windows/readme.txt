# Tipo de instalação
	Selecione a instalação completa

#link para setar na instalacao em remote targets
	http://glpi.yourdomain.com.br/front/inventory.php

#link para forcar invetori
	localhost:62354

#export info manual
	## execute o cmd como administrador
	"C:\Program Files\GLPI-Agent\glpi-inventory.bat" > c:\inventory.xml
	"C:\Program Files\GLPI-Agent\glpi-inventory.bat" --json > c:\inventory.json